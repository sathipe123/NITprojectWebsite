$(document).ready(function(){

$("#login").click(function(){
		$("#myrequesttable").show();
		$("#myviewdetails").hide();
	    $("#myupdatestatus").hide();
	    $("#myadd").hide();
	});
	



});